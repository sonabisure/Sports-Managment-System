import { Teams } from './teams';

describe('Teams', () => {
  it('should create an instance', () => {
    expect(new Teams()).toBeTruthy();
  });
});
