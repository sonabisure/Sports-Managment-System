export class Teams {

    team_id!:number;
    sport_name!:String;
    team_name!:String;
    city!:String;
    country!:String;  

}
